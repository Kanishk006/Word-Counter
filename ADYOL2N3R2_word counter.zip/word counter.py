w=input()
wc=len(w)
print(wc)